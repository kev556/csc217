#ifndef MYSTRLEN_H_
#define MYSTRLEN_H_
    size_t mystrlen(const char *s);
#endif