#ifndef CLIINPUT_H_
#define CLIINPUT_H_
    void cliInput(int argc, char **argv, char **arr, char **max, int *maxlen);
#endif