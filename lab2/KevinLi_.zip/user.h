#ifndef USERINPUT_H_
#define USERINPUT_H_
    void userInput(char **arr, char **max, int *maxlen);
#endif